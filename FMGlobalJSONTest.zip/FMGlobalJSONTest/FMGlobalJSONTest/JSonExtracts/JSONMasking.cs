﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMGlobalJSONTest
{
    
    public class JSONMasking:FileExtractor
    {
        JObject jObject;
        public void ReadFile(string filePath)
        {
            var jsonString = File.ReadAllText(filePath);
            jObject = JObject.Parse(jsonString);
           
        }

        public IList<string> GetJsonList(string key)
        {
            IList<string> values = jObject.SelectToken(key).Select(s => (string)s).ToList();
            return values;
        }

        public IList<JToken> GetJsonListObject(string key)
        {
            IList<JToken> values = jObject.SelectToken(key).Select(s => s).ToList();
            return values;
        }

       

    }
}
