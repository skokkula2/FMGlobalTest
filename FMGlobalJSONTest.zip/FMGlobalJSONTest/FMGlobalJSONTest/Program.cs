﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMGlobalJSONTest
{

    class Program
    {
        
        static void Main(string[] args)
        {
            //Path configured and loading the file - Json formats, collected content in array list. 
            string filePath = Environment.CurrentDirectory;
            JSONMasking JSONMasking = new JSONMasking();
            JSONMasking.ReadFile(filePath+ "/DataFiles/DataElementsForMasking.json");
            IList<string> maskedFileds=JSONMasking.GetJsonList("MaskDataElements");
            JSONMasking.ReadFile(filePath + "/DataFiles/SampleJson.json");
            IList<JToken> sampleFile= JSONMasking.GetJsonListObject("output");

            // find AddressLine1 from Sample Json file using attribute

            
            

        }
    }
}
